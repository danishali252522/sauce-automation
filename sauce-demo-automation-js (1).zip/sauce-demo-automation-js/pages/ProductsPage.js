// pages/ProductsPage.js
const { expect } = require('@playwright/test');

class ProductsPage {
  constructor(page) {
    this.page = page;
    this.pageTitle = page.locator('.title');
    this.inventoryContainer = page.locator('.inventory_container');
    this.cartIcon = page.locator('.shopping_cart_link');
    this.cartBadge = page.locator('.shopping_cart_badge');
    this.menuButton = page.locator('#react-burger-menu-btn');
    this.logoutLink = page.locator('#logout_sidebar_link');
  }

  async verifyProductsPageLoaded() {
    await expect(this.pageTitle).toHaveText('Products');
    await expect(this.inventoryContainer).toBeVisible();
  }

  async addProductToCart(productName) {
    const addToCartButton = this.page.locator(`[data-test="add-to-cart-${productName.toLowerCase().replace(/\s+/g, '-')}"]`);
    await addToCartButton.click();
  }

  async getCartItemCount() {
    try {
      const count = await this.cartBadge.textContent();
      return count || '0';
    } catch {
      return '0';
    }
  }

  async goToCart() {
    await this.cartIcon.click();
  }

  async logout() {
    await this.menuButton.click();
    await this.logoutLink.click();
  }

  async verifyProductInInventory(productName) {
    const productElement = this.page.locator('.inventory_item').filter({ hasText: productName });
    await expect(productElement).toBeVisible();
  }
}

module.exports = { ProductsPage };