// pages/CartPage.js
const { expect } = require('@playwright/test');

class CartPage {
  constructor(page) {
    this.page = page;
    this.pageTitle = page.locator('.title');
    this.cartItems = page.locator('.cart_item');
    this.checkoutButton = page.locator('[data-test="checkout"]');
    this.continueShoppingButton = page.locator('[data-test="continue-shopping"]');
    this.removeButton = page.locator('[data-test^="remove-"]');
  }

  async verifyCartPageLoaded() {
    await expect(this.pageTitle).toHaveText('Your Cart');
  }

  async verifyProductInCart(productName) {
    const cartItem = this.cartItems.filter({ hasText: productName });
    await expect(cartItem).toBeVisible();
  }

  async proceedToCheckout() {
    await this.checkoutButton.click();
  }

  async getCartItemsCount() {
    return await this.cartItems.count();
  }
}

module.exports = { CartPage };