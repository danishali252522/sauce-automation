// tests/full-workflow.spec.js
const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { ProductsPage } = require('../pages/ProductsPage');
const { CartPage } = require('../pages/CartPage');
const { CheckoutPage } = require('../pages/CheckoutPage');
const { CheckoutCompletePage } = require('../pages/CheckoutCompletePage');
const { ApiHelper } = require('../utils/ApiHelper');
const { TestData } = require('../utils/TestData');

test.describe('Complete Workflow Tests', () => {
  test('Complete User Journey: Login → Shop → Checkout + Weather API', async ({ page, request }) => {
    // Initialize page objects
    const loginPage = new LoginPage(page);
    const productsPage = new ProductsPage(page);
    const cartPage = new CartPage(page);
    const checkoutPage = new CheckoutPage(page);
    const checkoutCompletePage = new CheckoutCompletePage(page);
    const apiHelper = new ApiHelper(request);

    // Step 1: Login
    await loginPage.goto();
    await loginPage.login(
      TestData.validUsers.standard.username,
      TestData.validUsers.standard.password
    );
    await productsPage.verifyProductsPageLoaded();

    // Step 2: Add product to cart
    await productsPage.addProductToCart(TestData.products.backpack);
    expect(await productsPage.getCartItemCount()).toBe('1');

    // Step 3: Go to cart and verify
    await productsPage.goToCart();
    await cartPage.verifyCartPageLoaded();
    await cartPage.verifyProductInCart('Sauce Labs Backpack');

    // Step 4: Checkout process
    await cartPage.proceedToCheckout();
    await checkoutPage.verifyCheckoutPageLoaded();
    await checkoutPage.fillCheckoutInformation(
      TestData.checkoutInfo.firstName,
      TestData.checkoutInfo.lastName,
      TestData.checkoutInfo.postalCode
    );
    await checkoutPage.clickContinue();
    await checkoutPage.verifyCheckoutOverviewPage();
    await checkoutPage.finishOrder();

    // Step 5: Verify order completion
    await checkoutCompletePage.verifyOrderComplete();

    // Step 6: API Test - Weather for Islamabad
    if (process.env.OPENWEATHER_API_KEY) {
      const weatherData = await apiHelper.verifyIslamabadWeather(process.env.OPENWEATHER_API_KEY);
      console.log(`Order completed successfully! Current weather in Islamabad: ${weatherData.main.temp}°C`);
    }
  });
});