// tests/simple-api-check.spec.js
const { test } = require('@playwright/test');

test('Simple API Check', async ({ request }) => {
  const apiKey = 'Of9db80bf7f64bc269cfbb7d74f92d9a8';
  const url = `https://api.openweathermap.org/data/2.5/weather?q=London&appid=${apiKey}&units=metric`;
  
  console.log('Testing with London (simpler query)...');
  console.log('URL:', url.replace(apiKey, 'HIDDEN'));
  
  const response = await request.get(url);
  console.log('Status:', response.status());
  
  const responseText = await response.text();
  console.log('Response:', responseText);
  
  if (response.status() === 200) {
    console.log('✅ API Key is working!');
  } else if (response.status() === 401) {
    console.log('❌ API Key is invalid or not activated yet');
    console.log('💡 Wait 10-60 minutes after creating your OpenWeather account');
  } else {
    console.log('❓ Unexpected status code:', response.status());
  }
});