// tests/e2e-order.spec.js
const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { ProductsPage } = require('../pages/ProductsPage');
const { CartPage } = require('../pages/CartPage');
const { CheckoutPage } = require('../pages/CheckoutPage');
const { CheckoutCompletePage } = require('../pages/CheckoutCompletePage');
const { TestData } = require('../utils/TestData');

test.describe('End-to-End Order Tests', () => {
  let loginPage;
  let productsPage;
  let cartPage;
  let checkoutPage;
  let checkoutCompletePage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    productsPage = new ProductsPage(page);
    cartPage = new CartPage(page);
    checkoutPage = new CheckoutPage(page);
    checkoutCompletePage = new CheckoutCompletePage(page);

    // Login before each test
    await loginPage.goto();
    await loginPage.login(
      TestData.validUsers.standard.username,
      TestData.validUsers.standard.password
    );
    await productsPage.verifyProductsPageLoaded();
  });

  test('Scenario 2: User Places Order and Checks Out Successfully', async ({ page }) => {
    // Verify user is on Product Page
    await productsPage.verifyProductsPageLoaded();

    // Select a product by clicking "Add to Cart"
    await productsPage.addProductToCart(TestData.products.backpack);
    
    // Verify cart badge shows 1 item
    expect(await productsPage.getCartItemCount()).toBe('1');

    // Click on Cart button and navigate to Your Cart page
    await productsPage.goToCart();
    await cartPage.verifyCartPageLoaded();

    // Confirm selected product is added to cart
    await cartPage.verifyProductInCart('Sauce Labs Backpack');
    expect(await cartPage.getCartItemsCount()).toBe(1);

    // Click Checkout button
    await cartPage.proceedToCheckout();
    await checkoutPage.verifyCheckoutPageLoaded();

    // Fill out checkout information
    await checkoutPage.fillCheckoutInformation(
      TestData.checkoutInfo.firstName,
      TestData.checkoutInfo.lastName,
      TestData.checkoutInfo.postalCode
    );

    // Click Continue button
    await checkoutPage.clickContinue();
    await checkoutPage.verifyCheckoutOverviewPage();

    // Click Finish button after confirming order details
    await checkoutPage.finishOrder();

    // Verify order placed successfully with "Thank You for Your Order" message
    await checkoutCompletePage.verifyOrderComplete();
  });

  test('Add Multiple Products to Cart and Checkout', async ({ page }) => {
    // Add multiple products
    await productsPage.addProductToCart(TestData.products.backpack);
    await productsPage.addProductToCart(TestData.products.bikeLight);
    
    // Verify cart has 2 items
    expect(await productsPage.getCartItemCount()).toBe('2');

    // Go to cart and verify both products
    await productsPage.goToCart();
    await cartPage.verifyCartPageLoaded();
    await cartPage.verifyProductInCart('Sauce Labs Backpack');
    await cartPage.verifyProductInCart('Sauce Labs Bike Light');

    // Complete checkout process
    await cartPage.proceedToCheckout();
    await checkoutPage.fillCheckoutInformation(
      TestData.checkoutInfo.firstName,
      TestData.checkoutInfo.lastName,
      TestData.checkoutInfo.postalCode
    );
    await checkoutPage.clickContinue();
    await checkoutPage.finishOrder();
    await checkoutCompletePage.verifyOrderComplete();
  });
});