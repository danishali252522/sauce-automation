// tests/login.spec.js
const { test, expect } = require('@playwright/test');
const { LoginPage } = require('../pages/LoginPage');
const { ProductsPage } = require('../pages/ProductsPage');
const { TestData } = require('../utils/TestData');

test.describe('Login Tests', () => {
  let loginPage;
  let productsPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    productsPage = new ProductsPage(page);
    await loginPage.goto();
  });

  test('Scenario 1: Verify User Login with Valid Credentials', async ({ page }) => {
    // Verify login page elements are visible
    await loginPage.verifyLoginPageElements();

    // Enter valid credentials and login
    await loginPage.login(
      TestData.validUsers.standard.username,
      TestData.validUsers.standard.password
    );

    // Verify user is successfully logged in and navigated to Products page
    await productsPage.verifyProductsPageLoaded();
    
    // Verify URL contains inventory
    expect(page.url()).toContain('/inventory.html');
  });

  test('Verify Login with Locked User Shows Error', async ({ page }) => {
    await loginPage.login(
      TestData.invalidUsers.locked.username,
      TestData.invalidUsers.locked.password
    );

    // Verify error message appears
    await loginPage.verifyErrorMessage('Epic sadface: Sorry, this user has been locked out.');
  });

  test('Verify Login with Invalid Credentials Shows Error', async ({ page }) => {
    await loginPage.login('invalid_user', 'invalid_password');

    // Verify error message appears
    await loginPage.verifyErrorMessage('Epic sadface: Username and password do not match any user in this service');
  });
});