// tests/api-weather.spec.js
const { test, expect } = require('@playwright/test');
const { ApiHelper } = require('../utils/ApiHelper');

test.describe('OpenWeather API Tests', () => {
  let apiHelper;

  test.beforeEach(async ({ request }) => {
    apiHelper = new ApiHelper(request);
  });

  test('Scenario 3: Verify Islamabad Weather API Response', async ({ request }) => {
    // Skip test if API key is not provided
    test.skip(!process.env.OPENWEATHER_API_KEY, 'OpenWeather API key not provided');

    const apiKey = process.env.OPENWEATHER_API_KEY;
    
    // Get weather data for Islamabad
    const weatherData = await apiHelper.verifyIslamabadWeather(apiKey);

    // Additional assertions
    expect(weatherData.cod).toBe(200);
    expect(weatherData.sys.country).toBe('PK');
    expect(weatherData.name).toBe('Islamabad');
    
    // Verify weather data structure
    expect(weatherData.main).toHaveProperty('temp');
    expect(weatherData.main).toHaveProperty('humidity');
    expect(weatherData.main).toHaveProperty('pressure');
    expect(weatherData.weather).toBeInstanceOf(Array);
    expect(weatherData.weather[0]).toHaveProperty('main');
    expect(weatherData.weather[0]).toHaveProperty('description');

    console.log('Weather API Test Results:');
    console.log(`City: ${weatherData.name}, ${weatherData.sys.country}`);
    console.log(`Temperature: ${weatherData.main.temp}°C`);
    console.log(`Feels like: ${weatherData.main.feels_like}°C`);
    console.log(`Humidity: ${weatherData.main.humidity}%`);
    console.log(`Weather: ${weatherData.weather[0].main} - ${weatherData.weather[0].description}`);
  });

  test('Verify API Response with Different City', async ({ request }) => {
    test.skip(!process.env.OPENWEATHER_API_KEY, 'OpenWeather API key not provided');

    const apiKey = process.env.OPENWEATHER_API_KEY;
    const karachiCityId = '1174872'; // Karachi city ID
    
    const { response, data } = await apiHelper.getWeatherData(karachiCityId, apiKey);
    
    expect(response.status()).toBe(200);
    expect(data.name).toBe('Karachi');
    expect(data.sys.country).toBe('PK');
    expect(typeof data.main.temp).toBe('number');
  });
});