// utils/ApiHelper.js
const { expect } = require('@playwright/test');
const { TestData } = require('./TestData');

class ApiHelper {
  constructor(request) {
    this.request = request;
  }

  async getWeatherData(cityId, apiKey) {
    const response = await this.request.get(
      `https://api.openweathermap.org/data/2.5/weather?id=${cityId}&appid=${apiKey}&units=metric`
    );
    
    expect(response.status()).toBe(200);
    
    const weatherData = await response.json();
    return {
      response,
      data: weatherData
    };
  }

  async verifyIslamabadWeather(apiKey) {
    const { response, data } = await this.getWeatherData(TestData.api.islamabadCityId, apiKey);
    
    // Verify response code
    expect(response.status()).toBe(200);
    
    // Verify city name
    expect(data.name).toBe('Islamabad');
    
    // Verify temperature exists and is a number
    expect(typeof data.main.temp).toBe('number');
    expect(data.main.temp).toBeGreaterThan(-50);
    expect(data.main.temp).toBeLessThan(60);
    
    console.log(`Current temperature in Islamabad: ${data.main.temp}°C`);
    console.log(`Weather condition: ${data.weather[0].description}`);
    
    return data;
  }
}

module.exports = { ApiHelper };