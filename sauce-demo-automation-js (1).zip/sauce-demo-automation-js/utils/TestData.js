// utils/TestData.js
const TestData = {
  validUsers: {
    standard: {
      username: 'standard_user',
      password: 'secret_sauce'
    },
    problem: {
      username: 'problem_user',
      password: 'secret_sauce'
    },
    performance: {
      username: 'performance_glitch_user',
      password: 'secret_sauce'
    },
    error: {
      username: 'error_user',
      password: 'secret_sauce'
    },
    visual: {
      username: 'visual_user',
      password: 'secret_sauce'
    }
  },
  invalidUsers: {
    locked: {
      username: 'locked_out_user',
      password: 'secret_sauce'
    }
  },
  checkoutInfo: {
    firstName: 'John',
    lastName: 'Doe',
    postalCode: '12345'
  },
  products: {
    backpack: 'sauce-labs-backpack',
    bikeLight: 'sauce-labs-bike-light',
    boltTShirt: 'sauce-labs-bolt-t-shirt',
    fleeceJacket: 'sauce-labs-fleece-jacket',
    onesie: 'sauce-labs-onesie',
    redTShirt: 'test.allthethings()-t-shirt-(red)'
  },
  api: {
    openWeatherApiKey: process.env.OPENWEATHER_API_KEY || 'your_api_key_here',
    islamabadCityId: '1176615'
  }
};

module.exports = { TestData };